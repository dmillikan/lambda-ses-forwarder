import json


def process_event(event, context):
 
    print(event)


    return
